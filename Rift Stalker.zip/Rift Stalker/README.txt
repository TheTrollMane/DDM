Rift-Stalker Dragon - Working Datapack + Resource Pack
======================================================

Target:
- Minecraft 1.21.1
- Dragon Survival 2.0.63
- NeoForge

This version registers the species, loads its custom UI textures/icons, and enables the
custom Rift-Stalker abilities/passives through Dragon Survival ability JSON plus
command functions.

How to install:
1. Put this datapack folder (or the zip) into:
   saves/YourWorldName/datapacks/
2. Put the separate "Rift Stalker Resource Pack" folder into:
   resourcepacks/
3. Enable the resource pack in Minecraft.
4. Run /reload (or restart the world)
5. Check with /datapack list
6. Use one of these:
   /dragon dragonsurvival:rift_stalker
   /dragon dragonsurvival:rift_stalker dragonsurvival:north dragonsurvival:newborn YourPlayerName

If you previously crashed after selecting the species, first load the world and run:
   /dragon dragonsurvival:human
Or from console / commands:
   /function rift_stalker:recover
Then reload and use the corrected command above.

Ability notes:
- Rift-Walker Phase: 3 second immobile channel, then prints clickable chat destinations: Overworld, Otherworld, Nether, End, and Aether. Each click opens an Immersive Portals rift for 5-10 seconds, then scheduled cleanup removes Rift-Stalker-tagged portal entities.
- Destination locks: Otherworld requires deeperdarker:main/enter_otherside, Nether requires minecraft:nether/root, End requires minecraft:end/root, and Aether requires aether:enter_aether. Overworld is always available as the return route.
- Rift duration reads the player score rift_stalker_growth_stage: growth stage 0 = 5s, 1 = 6s, 2 = 7s, 3 = 8s, 4 = 9s, 5+ = 10s. If you need to sync the function duration manually, use /scoreboard players set <player> rift_stalker_growth_stage <0-5>.
- Vertex Deconstruction: removes a 3x3x3 cube in front of your eyes, skipping bedrock.
- Wireframe Scan: glows nearby entities for 15 seconds and refreshes night vision.
- Reality Stutter: short blink with invisibility and rift particles.
- Void Walker: passive slow falling and emergency snap-back from below the world.
- Interdimensional Anchor: passive nausea clearing and penalty resistance, unlocked at adult growth.
- Night Vision: passive automatic night vision refresh.

Note:
- Rift-Walker Phase expects Immersive Portals' /portal command. The Otherworld button currently targets deeperdarker:otherside from Deeper and Darker. Dimension Teleport fallback functions are included under rift_stalker:rift_walker_phase/tpd_*.
- Additional Entity Attributes is installed as an attribute API mod. The current datapack uses Dragon Survival's penalty resistance attribute, but the full permanent-heart debt/recovery loop still needs a scoreboard or companion mod layer because Dragon Survival ability JSON does not provide a per-player persistent health-debt menu by itself.
