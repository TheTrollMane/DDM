execute if entity @s[y=-2032,dy=1968] run tp @s ~ 0 ~
execute if entity @s[y=-2032,dy=1968] run particle minecraft:portal ~ ~1 ~ 0.5 1 0.5 0.05 80 force
