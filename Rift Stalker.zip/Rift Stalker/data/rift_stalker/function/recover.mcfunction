execute as @a run dragon dragonsurvival:human
