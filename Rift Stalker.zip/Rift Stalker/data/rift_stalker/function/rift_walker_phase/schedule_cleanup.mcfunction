execute if score @s rift_stalker_growth_stage matches ..0 run schedule function rift_stalker:rift_walker_phase/cleanup 5s append
execute if score @s rift_stalker_growth_stage matches 1 run schedule function rift_stalker:rift_walker_phase/cleanup 6s append
execute if score @s rift_stalker_growth_stage matches 2 run schedule function rift_stalker:rift_walker_phase/cleanup 7s append
execute if score @s rift_stalker_growth_stage matches 3 run schedule function rift_stalker:rift_walker_phase/cleanup 8s append
execute if score @s rift_stalker_growth_stage matches 4 run schedule function rift_stalker:rift_walker_phase/cleanup 9s append
execute if score @s rift_stalker_growth_stage matches 5.. run schedule function rift_stalker:rift_walker_phase/cleanup 10s append
