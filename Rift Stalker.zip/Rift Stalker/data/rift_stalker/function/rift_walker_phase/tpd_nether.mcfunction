tpd @s 0 80 0 minecraft:the_nether
