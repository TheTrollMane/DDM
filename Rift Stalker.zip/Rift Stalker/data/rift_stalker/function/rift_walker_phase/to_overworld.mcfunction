scoreboard players set @s rift_stalker_rift 0
portal make_portal 2 3 minecraft:overworld 0 80 0
portal set_portal_nbt {portalTag:"rift_stalker_phase",unbreakable:true,defaultAnimation:{durationTicks:20}}
portal complete_bi_way_portal
particle minecraft:portal ~ ~1 ~ 0.7 1.2 0.7 0.08 120 force
playsound minecraft:block.portal.trigger player @s ~ ~ ~ 1 0.8
function rift_stalker:rift_walker_phase/schedule_cleanup
