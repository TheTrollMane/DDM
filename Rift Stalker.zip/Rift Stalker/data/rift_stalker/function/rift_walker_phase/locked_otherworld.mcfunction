scoreboard players set @s rift_stalker_rift 0
tellraw @s {"text":"Rift locked: discover the Otherworld first.","color":"dark_aqua"}
playsound minecraft:block.vault.deactivate player @s ~ ~ ~ 0.6 0.7
