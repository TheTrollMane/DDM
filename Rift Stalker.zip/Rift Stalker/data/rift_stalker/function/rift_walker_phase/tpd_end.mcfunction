tpd @s 100 50 0 minecraft:the_end
