import json
with open('tree.json','r',encoding='utf-8-sig') as f:
    data = json.load(f)
for node in data.get('tree', []):
    path = node.get('path', '')
    if 'dragon_species' in path or 'dragon_ability' in path or 'dragon_stage' in path or 'dragon/' in path:
        print(path)
